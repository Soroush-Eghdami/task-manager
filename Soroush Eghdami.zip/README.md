# 📝 Task Manager – Python Project

This is a simple and functional Task Manager written in Python, created as part of my programming exam.

## 🎯 Features

- ✅ Add new tasks with title, description, deadline, and priority
- 📋 List all tasks sorted by deadline or priority
- ✏️ Edit existing tasks
- ❌ Delete tasks
- ✔️ Mark tasks as completed
- 💾 Save and load tasks using a JSON file
- 🎨 Colored output based on task priority (High, Medium, Low)

## How to Run

1. Make sure you have Python 3.10 or newer installed.
2. Install the required package:

```bash
pip install -r requirements.txt
```

## How to use
- At first you'll see the menu choose you preferd option from the list
- Read the instruction when you enter the choice

